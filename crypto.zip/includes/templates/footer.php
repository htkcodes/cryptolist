
<footer>
<div class="container">
<a class="footer-logo text-center" style="margin:0 auto;" href="#">CryptoList</a>
</div>
</footer>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
<script src="assets/js/bootstrap.min.js"></script>
